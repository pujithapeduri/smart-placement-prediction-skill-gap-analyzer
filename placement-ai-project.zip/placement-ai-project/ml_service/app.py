from __future__ import annotations
from pathlib import Path
from typing import Any
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from .model_pipeline import train_model, predict, get_bundle, METRICS_PATH
import json

app = FastAPI(title="Placement AI Machine Learning API", version="1.0.0")

class PlacementInput(BaseModel):
    name: str = ""
    degree: str = ""
    branch: str = ""
    cgpa: float = 0
    backlogs: int = 0
    internships: int = 0
    projects: int = 0
    certifications: int = 0
    aptitude: float = 0
    communication: float = 0
    programming: float = 0
    dsa: float = 0
    webDevelopment: float = 0
    machineLearning: float = 0
    preferred_domain: str = ""

@app.on_event("startup")
def startup_event():
    train_model()

@app.get("/health")
def health():
    bundle = get_bundle()
    return {"status": "ok", "model": bundle["model"].named_steps["classifier"].__class__.__name__, "data_source": bundle["data_source"]}

@app.get("/model-info")
def model_info():
    if not METRICS_PATH.exists():
        train_model()
    return json.loads(METRICS_PATH.read_text(encoding="utf-8"))

@app.post("/predict")
def predict_endpoint(payload: PlacementInput):
    try:
        return predict(payload.model_dump())
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
