from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.metrics import accuracy_score, classification_report, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
ARTIFACT_DIR = ROOT / "ml_service" / "artifacts"
MODEL_PATH = ARTIFACT_DIR / "placement_model.joblib"
METRICS_PATH = ARTIFACT_DIR / "model_metrics.json"

TARGET = "placed"
FEATURES = [
    "age", "gender", "cgpa", "attendance_percentage", "backlogs",
    "coding_score", "aptitude_score", "communication_score", "technical_score",
    "projects_count", "major_projects", "internships_count", "internship_months",
    "certifications_count", "hackathons_participated", "hackathons_won",
    "coding_platform_score", "github_projects", "linkedin_score", "resume_score",
    "soft_skills_score", "leadership_score", "extracurricular_score",
    "training_hours", "mock_interview_score", "preferred_domain"
]
NUMERIC_FEATURES = [f for f in FEATURES if f not in ("gender", "preferred_domain")]
CATEGORICAL_FEATURES = ["gender", "preferred_domain"]

def _synthetic_training_data(n: int = 2500, seed: int = 42) -> pd.DataFrame:
    """Fallback only so the app can be tested before the user's CSV is added."""
    rng = np.random.default_rng(seed)
    df = pd.DataFrame({
        "age": rng.integers(20, 26, n),
        "gender": rng.choice(["Female", "Male", "Other"], n, p=[0.48, 0.49, 0.03]),
        "cgpa": np.round(rng.uniform(5.0, 10.0, n), 2),
        "attendance_percentage": np.round(rng.uniform(55, 100, n), 1),
        "backlogs": rng.integers(0, 5, n),
        "coding_score": rng.integers(20, 101, n),
        "aptitude_score": rng.integers(20, 101, n),
        "communication_score": rng.integers(25, 101, n),
        "technical_score": rng.integers(20, 101, n),
        "projects_count": rng.integers(0, 8, n),
        "major_projects": rng.integers(0, 4, n),
        "internships_count": rng.integers(0, 5, n),
        "internship_months": rng.integers(0, 19, n),
        "certifications_count": rng.integers(0, 13, n),
        "hackathons_participated": rng.integers(0, 8, n),
        "hackathons_won": rng.integers(0, 4, n),
        "coding_platform_score": rng.integers(0, 101, n),
        "github_projects": rng.integers(0, 16, n),
        "linkedin_score": rng.integers(20, 101, n),
        "resume_score": rng.integers(20, 101, n),
        "soft_skills_score": rng.integers(20, 101, n),
        "leadership_score": rng.integers(20, 101, n),
        "extracurricular_score": rng.integers(0, 101, n),
        "training_hours": rng.integers(0, 301, n),
        "mock_interview_score": rng.integers(20, 101, n),
        "preferred_domain": rng.choice(
            ["Software Development", "Data Science", "AI/ML", "Web Development", "Cybersecurity"], n
        )
    })
    # Synthetic label for UI testing only, not real-world placement evidence.
    raw = (
        (df["cgpa"] - 5) * 0.65
        + (df["coding_score"] / 100) * 0.9
        + (df["aptitude_score"] / 100) * 0.45
        + (df["communication_score"] / 100) * 0.35
        + (df["technical_score"] / 100) * 0.8
        + df["projects_count"] * 0.08
        + df["internships_count"] * 0.14
        + df["certifications_count"] * 0.025
        + df["mock_interview_score"] / 100 * 0.35
        - df["backlogs"] * 0.35
        + df["attendance_percentage"] / 100 * 0.15
        + rng.normal(0, 0.3, n)
    )
    df[TARGET] = (raw > 2.05).astype(int)
    return df

def _find_training_csv() -> Path | None:
    candidates = [
        DATA_DIR / "student_placement_train.csv",
        ROOT / "student_placement_train.csv",
        ROOT / "datasets" / "student_placement_train.csv",
    ]
    return next((p for p in candidates if p.exists()), None)

def train_model(force: bool = False) -> dict[str, Any]:
    ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)
    if MODEL_PATH.exists() and METRICS_PATH.exists() and not force:
        return json.loads(METRICS_PATH.read_text(encoding="utf-8"))

    csv_path = _find_training_csv()
    if csv_path:
        raw_df = pd.read_csv(csv_path)
        data_source = f"dataset:{csv_path.name}"
        if TARGET not in raw_df.columns:
            raise ValueError(f"Training CSV must contain target column '{TARGET}'.")
        missing = [c for c in FEATURES if c not in raw_df.columns]
        if missing:
            raise ValueError("Training CSV is missing required columns: " + ", ".join(missing))
        df = raw_df[FEATURES + [TARGET]].copy()
    else:
        df = _synthetic_training_data()
        data_source = "synthetic-demo-data (replace with student_placement_train.csv for real training)"

    df[TARGET] = pd.to_numeric(df[TARGET], errors="coerce")
    df = df[df[TARGET].isin([0, 1])].copy()
    if df[TARGET].nunique() < 2:
        raise ValueError("Target column 'placed' must contain both 0 and 1 classes.")
    X = df[FEATURES]
    y = df[TARGET].astype(int)

    numeric_pipeline = Pipeline([("imputer", SimpleImputer(strategy="median"))])
    categorical_pipeline = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore"))
    ])
    preprocessor = ColumnTransformer([
        ("numeric", numeric_pipeline, NUMERIC_FEATURES),
        ("categorical", categorical_pipeline, CATEGORICAL_FEATURES)
    ])
    model = Pipeline([
        ("preprocess", preprocessor),
        ("classifier", RandomForestClassifier(
            n_estimators=250, max_depth=None, min_samples_leaf=2,
            class_weight="balanced", random_state=42, n_jobs=-1
        ))
    ])

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    probs = model.predict_proba(X_test)[:, 1]
    metrics = {
        "model": "RandomForestClassifier",
        "source": data_source,
        "rows_used": int(len(df)),
        "features": FEATURES,
        "target": TARGET,
        "test_size": 0.2,
        "accuracy": round(float(accuracy_score(y_test, pred)), 4),
        "roc_auc": round(float(roc_auc_score(y_test, probs)), 4) if y_test.nunique() == 2 else None,
        "classification_report": classification_report(y_test, pred, output_dict=True, zero_division=0),
        "warning": (
            "Synthetic demo data was used. Metrics are not evidence of real placement performance."
            if not csv_path else
            "Evaluate on a held-out dataset and check for data leakage before reporting these metrics."
        )
    }
    joblib.dump({"model": model, "features": FEATURES, "data_source": data_source}, MODEL_PATH)
    METRICS_PATH.write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    return metrics

def get_bundle():
    if not MODEL_PATH.exists():
        train_model()
    return joblib.load(MODEL_PATH)

def _default_profile() -> dict[str, Any]:
    return {
        "age": 21, "gender": "Not specified", "cgpa": 0, "attendance_percentage": 75,
        "backlogs": 0, "coding_score": 0, "aptitude_score": 0, "communication_score": 0,
        "technical_score": 0, "projects_count": 0, "major_projects": 0, "internships_count": 0,
        "internship_months": 0, "certifications_count": 0, "hackathons_participated": 0,
        "hackathons_won": 0, "coding_platform_score": 0, "github_projects": 0,
        "linkedin_score": 50, "resume_score": 50, "soft_skills_score": 50,
        "leadership_score": 50, "extracurricular_score": 50, "training_hours": 0,
        "mock_interview_score": 0, "preferred_domain": "Software Development"
    }

def map_dashboard_input(payload: dict[str, Any]) -> dict[str, Any]:
    """Map the existing dashboard fields into the trained model's feature schema."""
    p = _default_profile()
    cgpa = float(payload.get("cgpa") or 0)
    programming = float(payload.get("programming") or 0)
    dsa = float(payload.get("dsa") or 0)
    web = float(payload.get("webDevelopment") or 0)
    ml = float(payload.get("machineLearning") or 0)
    aptitude = float(payload.get("aptitude") or 0)
    communication = float(payload.get("communication") or 0)
    projects = int(float(payload.get("projects") or 0))
    internships = int(float(payload.get("internships") or 0))
    certifications = int(float(payload.get("certifications") or 0))
    p.update({
        "cgpa": cgpa,
        "backlogs": int(float(payload.get("backlogs") or 0)),
        "coding_score": programming,
        "aptitude_score": aptitude,
        "communication_score": communication,
        "technical_score": round((programming + dsa + web + ml) / 4, 2),
        "projects_count": projects,
        "major_projects": min(projects, 3),
        "internships_count": internships,
        "certifications_count": certifications,
        "preferred_domain": str(payload.get("preferred_domain") or payload.get("branch") or "Software Development"),
        "soft_skills_score": communication,
        "mock_interview_score": round((aptitude + communication + programming) / 3, 2),
        "coding_platform_score": programming,
        "github_projects": projects,
        "resume_score": round(min(100, 35 + projects * 8 + certifications * 2), 2),
    })
    return p

def predict(payload: dict[str, Any]) -> dict[str, Any]:
    bundle = get_bundle()
    profile = map_dashboard_input(payload)
    row = pd.DataFrame([{key: profile.get(key) for key in bundle["features"]}])
    model = bundle["model"]
    probability = float(model.predict_proba(row)[0][1])
    predicted = int(probability >= 0.5)
    # Surface skill gaps as transparent coaching signals; they are not ML predictions.
    gaps = [
        ("Data Structures & Algorithms", float(payload.get("dsa") or 0)),
        ("Communication", float(payload.get("communication") or 0)),
        ("Machine Learning", float(payload.get("machineLearning") or 0)),
        ("Web Development", float(payload.get("webDevelopment") or 0)),
        ("Aptitude", float(payload.get("aptitude") or 0)),
        ("Programming", float(payload.get("programming") or 0)),
    ]
    priorities = [
        {"skill": name, "score": score, "target": max(80, min(95, int(score + 15)))}
        for name, score in sorted(gaps, key=lambda item: item[1])[:3]
    ]
    role = "ML Engineer" if float(payload.get("machineLearning") or 0) >= max(
        float(payload.get("webDevelopment") or 0), float(payload.get("programming") or 0)
    ) else ("Frontend Developer" if float(payload.get("webDevelopment") or 0) > float(payload.get("programming") or 0) else "Software Developer")
    return {
        "probability": round(probability * 100),
        "placed_prediction": predicted,
        "status": "Higher estimated likelihood" if predicted else "Lower estimated likelihood",
        "suggestedRole": role,
        "skillAverage": round(np.mean([v for _, v in gaps])),
        "priorities": priorities,
        "model": bundle["model"].named_steps["classifier"].__class__.__name__,
        "data_source": bundle["data_source"],
        "note": "Probability from a Random Forest classifier. This is an estimate, not a guarantee of placement."
    }
