# Placement AI — Smart Placement Prediction & Skill Gap Analyzer

React + Tailwind CSS dashboard with a Node.js/Express API and a Python machine-learning service.

## Features
- Login screen (demo login only)
- Placement prediction using a scikit-learn Random Forest classifier
- Skill-gap analysis and career-insight charts (the latter use sample data)
- Student profile and sample notification UI
- Express API proxies prediction requests to the Python ML service

## Tech stack
- React, JavaScript, Tailwind CSS, custom CSS, Vite
- Node.js, Express, CORS
- Python, FastAPI, pandas, NumPy, scikit-learn, joblib
- Recharts, Lucide React

## Run the project
Requirements: Node.js 18+ and Python 3.10+.

1. Extract the ZIP and open the project directory.
2. Install Node dependencies:
   ```bash
   npm install
   ```
3. Create and activate a Python virtual environment (Windows PowerShell):
   ```powershell
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1
   pip install -r requirements-ml.txt
   ```
   On macOS/Linux, activate with `source .venv/bin/activate`.
4. Start the frontend, Express API, and ML service together:
   ```bash
   npm run dev
   ```
5. Open http://localhost:5173.
   - Express API: http://localhost:5000/api/health
   - ML service health: http://127.0.0.1:8000/health
   - ML metrics: http://127.0.0.1:8000/model-info

## Use your placement dataset
The training script looks for `data/student_placement_train.csv` first. Copy your real training CSV into a new `data` folder at that path. It must contain the target column `placed` (0 = not placed, 1 = placed) and these feature columns:

`age, gender, cgpa, attendance_percentage, backlogs, coding_score, aptitude_score, communication_score, technical_score, projects_count, major_projects, internships_count, internship_months, certifications_count, hackathons_participated, hackathons_won, coding_platform_score, github_projects, linkedin_score, resume_score, soft_skills_score, leadership_score, extracurricular_score, training_hours, mock_interview_score, preferred_domain`

When the CSV exists, the Random Forest model trains from it and saves `ml_service/artifacts/placement_model.joblib` and `model_metrics.json`. The first startup trains the model; later startups reuse the saved model. Delete those two artifacts to retrain after replacing the CSV.

If no CSV is found, the project creates a synthetic demo dataset so the ML service can run and be tested. Predictions and metrics from synthetic data are only a technical demonstration and must not be presented as validated real-world placement results.

## Model
- Algorithm: RandomForestClassifier from scikit-learn
- Preprocessing: median imputation for numeric fields; most-frequent imputation and one-hot encoding for categorical fields
- Evaluation: stratified 80/20 train/test split, accuracy, ROC-AUC, and classification report
- The dashboard's fields are mapped into the model feature schema. Some model features not collected by the current form receive defaults, so for a stronger academic model, expand the form to collect all features or train a reduced-feature model.

## Important limitations
- Login is not production-grade authentication.
- Student data is not stored in a database.
- Skill-gap and career-insight pages still use illustrative sample data; only placement prediction calls the trained classifier.
- Model estimates are not guarantees of job placement.
