import React from 'react';
export default function SkillSlider({ label, value, onChange }) {
  return <label className="skill-slider">
    <span className="slider-label"><span>{label}</span><strong>{value}<small>/100</small></strong></span>
    <input type="range" min="0" max="100" value={value} onChange={e => onChange(Number(e.target.value))} style={{ '--range-progress': `${value}%` }} />
  </label>;
}
