import React from 'react';
import { BrainCircuit, Gauge, ChartNoAxesCombined, Target, X } from 'lucide-react';

const links = [
  { id: 'prediction', label: 'Prediction', icon: Gauge },
  { id: 'skill-gap', label: 'Skill Gap Analysis', icon: Target },
  { id: 'insights', label: 'Career Insights', icon: ChartNoAxesCombined }
];

export default function Sidebar({ page, setPage, open, close }) {
  return (
    <>
      {open && <button aria-label="Close menu overlay" className="mobile-overlay" onClick={close} />}
      <aside className={`sidebar ${open ? 'sidebar-open' : ''}`}>
        <div className="brand-row">
          <div className="brand-icon"><BrainCircuit size={20} /></div>
          <div><div className="brand-name">PLACEMENT<span>AI</span></div><div className="brand-sub">STUDENT INTELLIGENCE</div></div>
          <button className="mobile-close" onClick={close} aria-label="Close menu"><X size={18} /></button>
        </div>
        <div className="nav-caption">WORKSPACE</div>
        <nav className="nav-list">
          {links.map(({ id, label, icon: Icon }) => (
            <button key={id} onClick={() => { setPage(id); close(); }} className={`nav-item ${page === id ? 'active' : ''}`}>
              <Icon size={17} strokeWidth={1.8} /><span>{label}</span>
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="status-dot" />
          <div><div className="bottom-title">Placement season 2026</div><div className="bottom-sub">Your next chapter starts here.</div></div>
        </div>
      </aside>
    </>
  );
}
