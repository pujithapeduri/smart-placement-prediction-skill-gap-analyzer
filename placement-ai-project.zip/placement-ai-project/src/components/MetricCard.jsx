import React from 'react';
export default function MetricCard({ label, value, detail, icon: Icon, accent = 'purple' }) {
  return <div className={`metric-card metric-${accent}`}>
    <div className="metric-top"><span>{label}</span>{Icon && <div className="metric-icon"><Icon size={17} /></div>}</div>
    <div className="metric-value">{value}</div>
    <div className="metric-detail">{detail}</div>
  </div>;
}
