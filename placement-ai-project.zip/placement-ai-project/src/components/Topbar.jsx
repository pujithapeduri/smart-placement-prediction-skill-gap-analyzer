import React, { useState } from 'react';
import { Menu, Bell, CircleHelp, ChevronDown, UserRound, LogOut, X, CheckCheck } from 'lucide-react';

export default function Topbar({ onMenu, user, onLogout }) {
  const [showStudent, setShowStudent] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [read, setRead] = useState(false);
  const notifications = [
    { title: 'Complete your student profile', detail: 'Add academic and skill details to personalize your prediction.', time: 'Just now', unread: !read },
    { title: 'Your skill action plan is ready', detail: 'Visit Skill Gap Analysis to see recommended next steps.', time: 'Today', unread: !read }
  ];
  return (
    <header className="topbar">
      <button className="icon-button menu-button" aria-label="Open menu" onClick={onMenu}><Menu size={22} /></button>
      <div className="breadcrumb"><span>Workspace</span><span className="crumb-slash">/</span><strong>Student dashboard</strong></div>
      <div className="topbar-actions">
        <span className="live-pill"><i /> SYSTEM ONLINE</span>
        <button className="icon-button" aria-label="Help" title="Help"><CircleHelp size={20} /></button>
        <div className="topbar-popover-wrap">
          <button className={`icon-button bell-button ${!read ? 'has-notifications' : ''}`} aria-label="Notifications" title="Notifications" onClick={() => {setShowNotifications(v=>!v);setShowStudent(false);}}>
            <Bell size={21}/>{!read && <span className="notification-count">2</span>}
          </button>
          {showNotifications && <div className="top-popover notification-popover">
            <div className="popover-heading"><div><strong>Notifications</strong><small>{read ? 'You are all caught up' : '2 new updates'}</small></div><button className="popover-icon" aria-label="Close notifications" onClick={()=>setShowNotifications(false)}><X size={16}/></button></div>
            {notifications.map(n=><div className={`notification-item ${n.unread?'notification-unread':''}`} key={n.title}><span className="notification-dot"/><div><strong>{n.title}</strong><p>{n.detail}</p><small>{n.time}</small></div></div>)}
            <button className="mark-read-button" onClick={()=>setRead(true)}><CheckCheck size={15}/> Mark all as read</button>
          </div>}
        </div>
        <div className="topbar-popover-wrap">
          <button className={`student-profile-button ${showStudent?'student-profile-active':''}`} onClick={()=>{setShowStudent(v=>!v);setShowNotifications(false);}} aria-label="Open student details" title="Student details">
            <span className="avatar">{(user?.name || 'S').charAt(0).toUpperCase()}</span><span className="profile-name">{user?.name || 'Student'}</span><ChevronDown size={15}/>
          </button>
          {showStudent && <div className="top-popover student-popover">
            <div className="student-popover-header"><span className="avatar avatar-large">{(user?.name || 'S').charAt(0).toUpperCase()}</span><div><strong>{user?.name || 'Student'}</strong><small>Student account</small></div><button className="popover-icon" aria-label="Close student details" onClick={()=>setShowStudent(false)}><X size={16}/></button></div>
            <div className="student-detail-row"><span><UserRound size={15}/> Name</span><strong>{user?.name || 'Not provided'}</strong></div>
            <div className="student-detail-row"><span>College email</span><strong>{user?.email || 'Not provided'}</strong></div>
            <div className="student-detail-row"><span>Degree</span><strong>{user?.degree || 'B.Tech'}</strong></div>
            <div className="student-detail-row"><span>Branch</span><strong>{user?.branch || 'CSE'}</strong></div>
            <button className="logout-button" onClick={onLogout}><LogOut size={15}/> Sign out</button>
          </div>}
        </div>
      </div>
    </header>
  );
}
