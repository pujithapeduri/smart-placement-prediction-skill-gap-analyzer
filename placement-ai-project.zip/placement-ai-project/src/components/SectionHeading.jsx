import React from 'react';
export default function SectionHeading({ eyebrow, title, description, right }) {
  return <div className="section-heading">
    <div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1>{description && <p>{description}</p>}</div>
    {right && <div className="heading-right">{right}</div>}
  </div>;
}
