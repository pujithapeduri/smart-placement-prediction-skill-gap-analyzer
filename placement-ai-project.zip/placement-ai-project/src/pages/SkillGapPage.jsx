import React, { useEffect, useState } from 'react';
import { Target, BookOpen, Clock3, ArrowUpRight, CheckCircle2, AlertCircle } from 'lucide-react';
import SectionHeading from '../components/SectionHeading.jsx';
import Panel from '../components/Panel.jsx';
import MetricCard from '../components/MetricCard.jsx';

const fallback = {
  overallReadiness: 68,
  skills: [
    { name: 'Data Structures & Algorithms', current: 54, target: 85, level: 'Needs work' },
    { name: 'Problem Solving', current: 68, target: 85, level: 'In progress' },
    { name: 'Web Development', current: 72, target: 80, level: 'Good' },
    { name: 'Communication', current: 61, target: 82, level: 'Needs work' },
    { name: 'Aptitude', current: 76, target: 85, level: 'Good' },
    { name: 'Core CS Concepts', current: 64, target: 80, level: 'In progress' }
  ],
  recommendations: [
    { title: 'Practice DSA consistently', description: 'Solve 2–3 problems each day and revise arrays, strings, trees, and graphs.', duration: '4 weeks', priority: 'High' },
    { title: 'Build one deployable project', description: 'Create a complete application with authentication, API integration, and a clear README.', duration: '3 weeks', priority: 'High' },
    { title: 'Improve interview communication', description: 'Practice a 60-second introduction and explain one project aloud every day.', duration: '2 weeks', priority: 'Medium' }
  ]
};
export default function SkillGapPage() {
  const [data, setData] = useState(fallback);
  useEffect(() => { fetch('/api/skill-gap').then(r=>r.ok?r.json():null).then(d=>d&&setData(d)).catch(()=>{}); }, []);
  return <>
    <SectionHeading eyebrow="READINESS INTELLIGENCE / 02" title="Skill Gap Analysis" description="Compare your current skills with the levels employers typically expect." right={<span className="date-chip">PERSONALIZED REPORT</span>} />
    <div className="metrics-grid">
      <MetricCard label="Overall readiness" value={`${data.overallReadiness}%`} detail="Across key placement skills" icon={Target}/>
      <MetricCard label="Skills assessed" value={data.skills.length} detail="Technical + soft skills" icon={BookOpen} accent="blue"/>
      <MetricCard label="Focus areas" value={data.skills.filter(s=>s.current<s.target-15).length} detail="Highest-impact opportunities" icon={AlertCircle} accent="orange"/>
    </div>
    <Panel title="Current skill levels" subtitle="Current score compared with target readiness.">
      <div className="gap-chart-list">
        {data.skills.map((skill, i) => <div className="gap-row" key={skill.name}>
          <div className="gap-label"><span>{skill.name}</span><em className={`level-tag ${skill.current >= skill.target-10 ? 'level-good' : skill.current >= skill.target-17 ? 'level-mid' : 'level-low'}`}>{skill.level}</em></div>
          <div className="gap-bars"><div className="bar-track"><div className="bar-current" style={{width:`${skill.current}%`}} /></div><div className="bar-track target-track"><div className="bar-target" style={{width:`${skill.target}%`}} /></div></div>
          <div className="gap-values"><strong>{skill.current}</strong><span>/ {skill.target}</span></div>
        </div>)}
      </div>
      <div className="chart-legend"><span><i className="legend-current"/> Current skill</span><span><i className="legend-target"/> Target score</span></div>
    </Panel>
    <Panel title="Recommended action plan" subtitle="A few practical steps to close your biggest gaps." className="recommendations-panel">
      <div className="recommendation-list">{data.recommendations.map((item,i)=><div className="recommendation" key={item.title}>
        <div className="recommend-number">{String(i+1).padStart(2,'0')}</div><div className="recommend-main"><div className="recommend-title">{item.title}<span className={`priority-pill ${item.priority==='High'?'priority-high':''}`}>{item.priority} priority</span></div><p>{item.description}</p><div className="recommend-duration"><Clock3 size={13}/>{item.duration}</div></div><ArrowUpRight className="recommend-arrow" size={17}/>
      </div>)}</div>
    </Panel>
  </>;
}
