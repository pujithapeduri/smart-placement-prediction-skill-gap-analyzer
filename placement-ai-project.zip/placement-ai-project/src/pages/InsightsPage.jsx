import React, { useEffect, useState } from 'react';
import { BarChart3, TrendingUp, Users, Download } from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis } from 'recharts';
import SectionHeading from '../components/SectionHeading.jsx';
import Panel from '../components/Panel.jsx';

const fallback = {
  placementTrend: [
    {year:'2022',placed:58,notPlaced:42},{year:'2023',placed:64,notPlaced:36},{year:'2024',placed:69,notPlaced:31},{year:'2025',placed:74,notPlaced:26},{year:'2026',placed:79,notPlaced:21}
  ],
  skillsRadar: [
    {skill:'Programming',current:76,target:85},{skill:'DSA',current:54,target:85},{skill:'Aptitude',current:76,target:80},{skill:'Communication',current:61,target:82},{skill:'Projects',current:72,target:85},{skill:'Internships',current:58,target:75}
  ],
  roleDemand: [
    {role:'Software Developer',demand:'High',openings:42},{role:'Data Analyst',demand:'High',openings:28},{role:'ML Engineer',demand:'Growing',openings:19},{role:'Frontend Developer',demand:'High',openings:32}
  ]
};
const tooltipStyle = { background:'#111a2e', border:'1px solid #2b3750', borderRadius:10, color:'#e7ebf5', fontSize:12 };
export default function InsightsPage() {
  const [data,setData] = useState(fallback);
  useEffect(()=>{fetch('/api/insights').then(r=>r.ok?r.json():null).then(d=>d&&setData(d)).catch(()=>{});},[]);
  function downloadReport() {
    const blob = new Blob([JSON.stringify(data,null,2)],{type:'application/json'});
    const url = URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download='placement-career-insights.json'; a.click(); URL.revokeObjectURL(url);
  }
  return <>
    <SectionHeading eyebrow="LABOR MARKET / 03" title="Career Insights" description="Explore placement trends and compare the skills that matter for your career." right={<button className="secondary-button" onClick={downloadReport}><Download size={15}/> Export data</button>} />
    <div className="insights-grid">
      <Panel title="Placement trends" subtitle="Sample student placement rate by year." className="chart-panel">
        <div className="chart-container"><ResponsiveContainer width="100%" height="100%"><BarChart data={data.placementTrend} barGap={7}>
          <CartesianGrid strokeDasharray="3 3" stroke="#243047" vertical={false}/><XAxis dataKey="year" stroke="#7e8aa4" tickLine={false} axisLine={false}/><YAxis stroke="#7e8aa4" tickLine={false} axisLine={false} unit="%" width={38}/><Tooltip contentStyle={tooltipStyle} cursor={{fill:'#1b2640'}}/><Legend wrapperStyle={{fontSize:11,color:'#a9b4c9'}}/><Bar dataKey="placed" name="Placed" fill="#6978ff" radius={[5,5,0,0]} maxBarSize={34}/><Bar dataKey="notPlaced" name="Not placed" fill="#35415d" radius={[5,5,0,0]} maxBarSize={34}/>
        </BarChart></ResponsiveContainer></div>
        <div className="chart-footnote"><TrendingUp size={14}/> Illustrative trend: placement rate rises across the sample period.</div>
      </Panel>
      <Panel title="Skill profile" subtitle="Your current skills versus suggested target." className="chart-panel">
        <div className="chart-container radar-container"><ResponsiveContainer width="100%" height="100%"><RadarChart data={data.skillsRadar} outerRadius="68%">
          <PolarGrid stroke="#2b3750"/><PolarAngleAxis dataKey="skill" tick={{fill:'#aab5ca',fontSize:10}}/><PolarRadiusAxis angle={30} domain={[0,100]} tick={{fill:'#69758e',fontSize:9}} axisLine={false}/><Radar name="Current" dataKey="current" stroke="#7b6cff" fill="#7b6cff" fillOpacity={0.28}/><Radar name="Target" dataKey="target" stroke="#48b7f4" fill="#48b7f4" fillOpacity={0.08}/><Legend wrapperStyle={{fontSize:11,color:'#a9b4c9'}}/><Tooltip contentStyle={tooltipStyle}/>
        </RadarChart></ResponsiveContainer></div>
        <div className="chart-footnote"><BarChart3 size={14}/> Prioritize the dimensions with the largest gap.</div>
      </Panel>
    </div>
    <Panel title="Role demand snapshot" subtitle="Example role categories and relative opportunity counts." className="role-panel">
      <div className="table-wrap"><table className="data-table"><thead><tr><th>ROLE</th><th>DEMAND</th><th>OPPORTUNITY INDEX</th><th>STATUS</th></tr></thead><tbody>{data.roleDemand.map((r,i)=><tr key={r.role}><td><div className="role-name"><span className="role-index">0{i+1}</span>{r.role}</div></td><td>{r.demand}</td><td><div className="demand-bar"><span style={{width:`${r.openings/45*100}%`}}/></div></td><td><span className={`demand-status ${r.demand==='Growing'?'growing':''}`}><i/>{r.demand==='Growing'?'Emerging':'In demand'}</span></td></tr>)}</tbody></table></div>
      <div className="data-disclaimer"><Users size={14}/> Demo data for interface illustration. Validate role demand using current job postings.</div>
    </Panel>
  </>;
}
