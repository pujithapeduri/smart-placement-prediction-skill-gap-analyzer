import React, { useState } from 'react';
import { BrainCircuit, LockKeyhole, Mail, ArrowRight, GraduationCap, ShieldCheck } from 'lucide-react';

export default function LoginPage({ onLogin }) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  function submit(e) {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !password.trim()) {
      setError('Please complete all fields to continue.');
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setError('Please enter a valid email address.');
      return;
    }
    // Demo-only login. Add a real authentication provider for production use.
    onLogin({ name: name.trim(), email: email.trim(), degree: 'B.Tech', branch: 'CSE' });
  }

  return (
    <div className="login-screen">
      <div className="login-glow login-glow-one" /><div className="login-glow login-glow-two" />
      <div className="login-brand"><div className="brand-icon"><BrainCircuit size={23}/></div><div><div className="brand-name">PLACEMENT<span>AI</span></div><div className="brand-sub">STUDENT INTELLIGENCE</div></div></div>
      <div className="login-layout">
        <section className="login-intro">
          <div className="login-kicker"><span className="tiny-live"/> YOUR CAREER, WITH CLARITY</div>
          <h1>Turn your potential<br/>into <span>placement success.</span></h1>
          <p>A smarter workspace to understand your placement readiness, close skill gaps, and prepare for the career you want.</p>
          <div className="login-benefits">
            <div><span><GraduationCap size={18}/></span><section><strong>Know your readiness</strong><small>Get a personalized placement estimate.</small></section></div>
            <div><span><ShieldCheck size={18}/></span><section><strong>Build with direction</strong><small>Turn skill gaps into a practical action plan.</small></section></div>
          </div>
        </section>
        <form className="login-card" onSubmit={submit}>
          <div className="login-card-mark"><LockKeyhole size={20}/></div>
          <div className="eyebrow">STUDENT PORTAL</div>
          <h2>Welcome back</h2>
          <p className="login-subtitle">Sign in to open your placement dashboard.</p>
          <label className="login-field"><span>Student name</span><div><GraduationCap size={17}/><input value={name} onChange={e=>setName(e.target.value)} placeholder="Enter your full name" autoComplete="name"/></div></label>
          <label className="login-field"><span>College email</span><div><Mail size={17}/><input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@college.edu" autoComplete="email"/></div></label>
          <label className="login-field"><span>Password</span><div><LockKeyhole size={17}/><input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Enter password" autoComplete="current-password"/></div></label>
          {error && <div className="login-error" role="alert">{error}</div>}
          <button className="primary-button login-submit" type="submit">Sign in to dashboard <ArrowRight size={17}/></button>
          <div className="login-demo-note">Demo login: enter any name, valid email, and password.</div>
        </form>
      </div>
      <div className="login-footer">PLACEMENT AI <span>•</span> STUDENT CAREER INTELLIGENCE</div>
    </div>
  );
}
