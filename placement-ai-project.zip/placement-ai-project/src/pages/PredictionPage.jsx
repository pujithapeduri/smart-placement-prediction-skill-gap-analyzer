import React, { useState } from 'react';
import { Sparkles, RotateCcw, GraduationCap, BriefcaseBusiness, CircleCheck, TrendingUp, Target, LoaderCircle } from 'lucide-react';
import SectionHeading from '../components/SectionHeading.jsx';
import Panel from '../components/Panel.jsx';
import SkillSlider from '../components/SkillSlider.jsx';
import MetricCard from '../components/MetricCard.jsx';
import { initialProfile } from '../data/initialProfile.js';

const numberFields = [
  ['cgpa', 'CGPA (out of 10)', 0, 10, 0.1], ['backlogs', 'Active backlogs', 0, 20, 1],
  ['internships', 'Internships completed', 0, 10, 1], ['projects', 'Projects completed', 0, 20, 1],
  ['certifications', 'Certifications', 0, 30, 1]
];
const skillFields = [
  ['aptitude', 'Aptitude score'], ['programming', 'Programming'], ['dsa', 'Data Structures & Algorithms'],
  ['webDevelopment', 'Web Development'], ['machineLearning', 'Machine Learning'], ['communication', 'Communication']
];

export default function PredictionPage({ user }) {
  const [profile, setProfile] = useState({ ...initialProfile, name: user?.name || '' });
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [apiError, setApiError] = useState('');
  const update = (key, value) => setProfile(prev => ({ ...prev, [key]: value }));
  async function predict(e) {
    e.preventDefault();
    setApiError('');
    if (profile.cgpa === '' || Number(profile.cgpa) <= 0 || profile.cgpa > 10) {
      setApiError('Enter a valid CGPA between 0.1 and 10 before predicting.');
      return;
    }
    const required = ['aptitude','communication','programming','dsa','webDevelopment','machineLearning'];
    if (required.some(key => profile[key] === '' || Number(profile[key]) < 0 || Number(profile[key]) > 100)) {
      setApiError('Enter valid skill scores between 0 and 100.');
      return;
    }
    setLoading(true);
    try {
      const response = await fetch('/api/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(profile)
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Prediction failed.');
      setResult(data);
    } catch (error) {
      setApiError(error.message || 'Unable to connect to the machine-learning service.');
      setResult(null);
    } finally {
      setLoading(false);
    }
  }
  return <>
    <SectionHeading eyebrow="PREDICTIVE ANALYTICS / 01" title="Placement Prediction" description="Understand your placement readiness and discover where to focus next." right={<span className="date-chip"><span className="tiny-live" /> LIVE MODEL</span>} />
    <div className="prediction-layout">
      <form onSubmit={predict} className="prediction-form">
        <Panel title="Student profile" subtitle="Enter your academic and experience details.">
          <div className="form-grid">
            <label className="field full-field"><span>Full name</span><input value={profile.name} onChange={e=>update('name',e.target.value)} placeholder="Enter your name" /></label>
            <label className="field"><span>Degree</span><select value={profile.degree} onChange={e=>update('degree',e.target.value)}><option>B.Tech</option><option>B.E.</option><option>B.Sc</option><option>M.Tech</option><option>MCA</option></select></label>
            <label className="field"><span>Branch / specialization</span><select value={profile.branch} onChange={e=>update('branch',e.target.value)}><option>CSE</option><option>IT</option><option>ECE</option><option>EEE</option><option>Mechanical</option><option>Civil</option><option>AI & ML</option></select></label>
            {numberFields.map(([key, label, min, max, step]) => <label className="field" key={key}><span>{label}</span><input type="number" min={min} max={max} step={step} value={profile[key]} onChange={e=>update(key, e.target.value === '' ? '' : Number(e.target.value))} /></label>)}
          </div>
        </Panel>
        <Panel title="Skill self-assessment" subtitle="Rate your current confidence in each area.">
          <div className="sliders-grid">
            {skillFields.map(([key,label]) => <SkillSlider key={key} label={label} value={profile[key]} onChange={value=>update(key,value)} />)}
          </div>
        </Panel>
        {apiError && <div className="login-error prediction-error" role="alert">{apiError}</div>}
        <div className="form-actions"><button type="submit" className="primary-button" disabled={loading}>{loading ? <LoaderCircle className="spin" size={16}/> : <Sparkles size={16}/>} Predict placement <span>↗</span></button><button type="button" className="secondary-button" onClick={()=>{setProfile({ ...initialProfile, name: user?.name || '' });setResult(null);setApiError('')}}><RotateCcw size={15}/> Reset</button></div>
      </form>
      <div className="result-column">
        <Panel title="Placement probability" subtitle="Your estimated readiness score">
          {result ? <div className="result-content">
            <div className="score-ring" style={{'--score':`${result.probability}%`}}><div><strong>{result.probability}<small>%</small></strong><span>MODEL ESTIMATE</span></div></div>
            <div className="result-status"><CircleCheck size={15}/>{result.status}</div>
            <p className="result-note">{result.note}</p>{result.model && <p className="model-source">Model: {result.model} · {result.data_source?.includes("synthetic-demo-data") ? "demo training data" : "provided training dataset"}</p>}
            <div className="result-divider"/>
            <div className="result-stat"><span>Suggested role</span><strong>{result.suggestedRole}</strong></div>
            <div className="result-stat"><span>Average skill score</span><strong>{result.skillAverage}/100</strong></div>
            <div className="result-divider"/>
            <div className="priority-title">Top focus areas</div>
            {result.priorities?.map(item=><div className="priority-row" key={item.skill}><span>{item.skill}</span><strong>{item.score}%</strong></div>)}
          </div> : <div className="empty-result"><div className="empty-icon"><TrendingUp size={24}/></div><h3>Your results will appear here</h3><p>Fill in your profile and run a prediction to see your estimated placement probability.</p><div className="empty-tip"><Sparkles size={14}/> Tip: Include projects and internships for a more complete profile.</div></div>}
        </Panel>
        <div className="mini-info-card"><div className="mini-info-icon"><GraduationCap size={19}/></div><div><strong>Build your profile</strong><p>Small, consistent improvements to your skills can make a big difference.</p></div></div>
        <div className="mini-info-card"><div className="mini-info-icon blue"><BriefcaseBusiness size={18}/></div><div><strong>Get career-ready</strong><p>Use Skill Gap Analysis to turn your results into an actionable plan.</p></div></div>
      </div>
    </div>
  </>;
}
