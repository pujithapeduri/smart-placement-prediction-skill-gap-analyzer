export const initialProfile = {
  name: '', degree: '', branch: '', cgpa: '', backlogs: '',
  internships: '', projects: '', certifications: '',
  aptitude: 0, communication: 0, programming: 0, dsa: 0,
  webDevelopment: 0, machineLearning: 0
};
