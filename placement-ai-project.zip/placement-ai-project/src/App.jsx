import React, { useState } from 'react';
import Sidebar from './components/Sidebar.jsx';
import Topbar from './components/Topbar.jsx';
import LoginPage from './pages/LoginPage.jsx';
import PredictionPage from './pages/PredictionPage.jsx';
import SkillGapPage from './pages/SkillGapPage.jsx';
import InsightsPage from './pages/InsightsPage.jsx';

export default function App() {
  const [user, setUser] = useState(null);
  const [page, setPage] = useState('prediction');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  if (!user) return <LoginPage onLogin={setUser} />;

  return (
    <div className="app-shell">
      <Sidebar page={page} setPage={setPage} open={sidebarOpen} close={() => setSidebarOpen(false)} />
      <main className="main-area">
        <Topbar user={user} onMenu={() => setSidebarOpen(v => !v)} onLogout={() => setUser(null)} />
        <div className="page-content">
          {page === 'prediction' && <PredictionPage user={user} />}
          {page === 'skill-gap' && <SkillGapPage />}
          {page === 'insights' && <InsightsPage />}
        </div>
        <footer className="footer-note">PLACEMENT AI <span>•</span> Demo analytics for learning and planning</footer>
      </main>
    </div>
  );
}
