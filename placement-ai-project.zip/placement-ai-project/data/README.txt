Copy your real student_placement_train.csv into this folder.
The CSV must include the column 'placed' and all feature columns listed in the project README.
Do not put confidential student information into a public repository.
