/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: { extend: { colors: { ink: '#080d1b', panel: '#111a2e', line: '#25314a', accent: '#5d6bff' } } },
  plugins: []
};
