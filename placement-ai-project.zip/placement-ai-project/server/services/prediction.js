const ML_API = process.env.ML_API_URL || 'http://127.0.0.1:8000';

export async function predictPlacement(input = {}) {
  const response = await fetch(`${ML_API}/predict`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(input)
  });
  if (!response.ok) {
    const detail = await response.text();
    throw new Error(`ML service returned ${response.status}: ${detail}`);
  }
  return response.json();
}

export function getSkillGap() {
  return {
    overallReadiness: 68,
    skills: [
      { name: 'Data Structures & Algorithms', current: 54, target: 85, level: 'Needs work' },
      { name: 'Problem Solving', current: 68, target: 85, level: 'In progress' },
      { name: 'Web Development', current: 72, target: 80, level: 'Good' },
      { name: 'Communication', current: 61, target: 82, level: 'Needs work' },
      { name: 'Aptitude', current: 76, target: 85, level: 'Good' },
      { name: 'Core CS Concepts', current: 64, target: 80, level: 'In progress' }
    ],
    recommendations: [
      { title: 'Practice DSA consistently', description: 'Solve 2–3 problems each day and revise arrays, strings, trees, and graphs.', duration: '4 weeks', priority: 'High' },
      { title: 'Build one deployable project', description: 'Create a complete application with authentication, API integration, and a clear README.', duration: '3 weeks', priority: 'High' },
      { title: 'Improve interview communication', description: 'Practice a 60-second introduction and explain one project aloud every day.', duration: '2 weeks', priority: 'Medium' }
    ]
  };
}

export function getCareerInsights() {
  return {
    placementTrend: [
      { year: '2022', placed: 58, notPlaced: 42 },
      { year: '2023', placed: 64, notPlaced: 36 },
      { year: '2024', placed: 69, notPlaced: 31 },
      { year: '2025', placed: 74, notPlaced: 26 },
      { year: '2026', placed: 79, notPlaced: 21 }
    ],
    skillsRadar: [
      { skill: 'Programming', current: 76, target: 85 },
      { skill: 'DSA', current: 54, target: 85 },
      { skill: 'Aptitude', current: 76, target: 80 },
      { skill: 'Communication', current: 61, target: 82 },
      { skill: 'Projects', current: 72, target: 85 },
      { skill: 'Internships', current: 58, target: 75 }
    ],
    roleDemand: [
      { role: 'Software Developer', demand: 'High', openings: 42 },
      { role: 'Data Analyst', demand: 'High', openings: 28 },
      { role: 'ML Engineer', demand: 'Growing', openings: 19 },
      { role: 'Frontend Developer', demand: 'High', openings: 32 }
    ]
  };
}
