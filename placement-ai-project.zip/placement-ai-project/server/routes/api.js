import { Router } from 'express';
import { predictPlacement, getSkillGap, getCareerInsights } from '../services/prediction.js';

const router = Router();
router.get('/health', (_req, res) => res.json({ status: 'ok', service: 'placement-ai-api' }));
router.post('/predict', async (req, res) => {
  try {
    const result = await predictPlacement(req.body || {});
    res.json(result);
  } catch (error) {
    res.status(503).json({
      error: 'Machine-learning service is unavailable. Install requirements-ml.txt and run npm run dev.',
      details: error.message
    });
  }
});
router.get('/skill-gap', (_req, res) => res.json(getSkillGap()));
router.get('/insights', (_req, res) => res.json(getCareerInsights()));
export default router;
